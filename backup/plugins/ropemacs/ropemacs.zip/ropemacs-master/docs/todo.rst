TODO
====

> Public Release 1.0

> Public Release 0.6

* saving the old values of refactoring configs
* showing proposal type in code-assist
