
**Note:** *Please note that this project has been moved to* `GitHub python-rope / ropemode`_

.. _GitHub python-rope / ropemode: https://github.com/python-rope/ropemode


